class Write 	{
 //the text to the file.
}